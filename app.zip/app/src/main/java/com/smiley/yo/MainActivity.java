package com.smiley.yo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.smiley.yo.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //When the user taps the login button
    public void loginActivity(View view) {
        //code to respond to the button

        /*
        The Intent constructor takes two parameters, a Context and a Class
        The Context parameter is used first because the Activity class is a subclass of Context.
        The Class parameter of the app component, to which the system delivers the Intent, is the activity to start.
         */
        Intent intent = new Intent(this, Home.class);

        EditText editText = (EditText) findViewById(R.id.editTextTextEmailAddress);

        String message = editText.getText().toString();
        /*The putExtra() method adds the value of EditText to the intent.
        An Intent can carry data types as key-value pairs called extras.
        ESTRA_MESSAGE is a public constant
         */
        intent.putExtra(EXTRA_MESSAGE, message);
        /*The startActivity() method starts an instance of the DisplayMessageActivity
          that's specified by the Intent.*/
        startActivity(intent);
    }
}